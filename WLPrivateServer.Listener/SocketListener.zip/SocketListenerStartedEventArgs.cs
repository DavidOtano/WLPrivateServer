﻿using System;

namespace WLPrivateServer.Listener
{
	public class SocketListenerStartedEventArgs : EventArgs
	{
	}
}