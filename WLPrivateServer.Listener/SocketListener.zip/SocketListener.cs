﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WLPrivateServer.Listener
{
	public class SocketListener : IDisposable
	{
		private readonly Thread listenerThread;
		private readonly CancellationTokenSource cancellationTokenSource;

		public event EventHandler<SocketListenerStartedEventArgs> Started;

		public event EventHandler<ClientConnectedEventArgs> ClientConnected;

		public event EventHandler<SocketListenerStoppedEventArgs> Stopped;

		private SocketListener(int port, int backlog, CancellationTokenSource cancellationTokenSource)
		{
			this.cancellationTokenSource = cancellationTokenSource;

			listenerThread = new Thread(() =>
			{
				var serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

				serverSocket.Bind(new IPEndPoint(IPAddress.Any, port));

				serverSocket.Listen(backlog);

				serverSocket.Blocking = false;
				try
				{
					Started?.Invoke(this, new SocketListenerStartedEventArgs());

					while (!cancellationTokenSource.IsCancellationRequested)
					{
						try
						{
							Socket client = serverSocket.Accept();

							ClientConnected?.Invoke(this, new ClientConnectedEventArgs(client));
						}
						catch (SocketException ex)
						{
							if (ex.SocketErrorCode != SocketError.WouldBlock)
								throw;
						}

						Thread.Sleep(1);
					}
				}
				finally
				{
					serverSocket.Close();

					serverSocket.Dispose();

					Stopped?.Invoke(this, new SocketListenerStoppedEventArgs());
				}
			});
		}

		public static SocketListener Create(int port, int backlog)
		{
			return new SocketListener(port, backlog, new CancellationTokenSource());
		}

		public void Start()
		{
			listenerThread.Start();
		}

		public void Stop()
		{
			cancellationTokenSource.Cancel();

			listenerThread.Join();
		}

		public void Dispose()
		{
			cancellationTokenSource.Dispose();
		}
	}
}