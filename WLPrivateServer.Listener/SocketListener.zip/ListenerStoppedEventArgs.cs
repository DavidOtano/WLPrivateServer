﻿using System;

namespace WLPrivateServer.Listener
{
	public class SocketListenerStoppedEventArgs : EventArgs
	{
	}
}